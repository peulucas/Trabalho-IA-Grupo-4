import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- BASE DE CONHECIMENTO ---
fatos_vinculos = {
    ("Ana", "IA"): "cursa",
    ("Prof. Wallas", "IA"): "leciona",
    ("João", "IA"): "monitor",
    ("Carlos", "Redes"): "cursa",
    ("Guilherme", "Banco de Dados"): "cursa" 
}

fatos_arquivos = {
    "apostila_ia.pdf": "IA",
    "redes_resumo.pdf": "Redes",
    "modelagem_db.docx": "Banco de Dados"
}

class PedidoAcesso(BaseModel):
    usuario: str
    acao: str       # "abrir_arquivo" ou "enviar_link"
    alvo: str       # nome do arquivo ou a URL do link
    disciplina: str # disciplina alvo (ex: IA, Redes)

@app.post("/motor_inferencia")
def motor_inferencia(pedido: PedidoAcesso):
    
    # REGRA 1: ABRIR ARQUIVOS (Leitura)
    if pedido.acao == "abrir_arquivo":
        # Lógica Proposicional: Formato
        if not (pedido.alvo.endswith(".pdf") or pedido.alvo.endswith(".docx")):
            return {"status": "bloqueado", "motivo": f"Formato inválido ({pedido.alvo}). Apenas PDF/DOCX."}
        
        materia = fatos_arquivos.get(pedido.alvo)
        if not materia:
            return {"status": "bloqueado", "motivo": "Ficheiro não registado."}
        
        # Lógica de Primeira Ordem: Vínculo
        vinculo = fatos_vinculos.get((pedido.usuario, materia))
        if vinculo:
            return {"status": "permitido", "mensagem": f"Acesso liberado à leitura. (Você {vinculo} a disciplina de {materia})."}
        else:
            return {"status": "bloqueado", "motivo": f"Acesso negado. Não possui vínculo com {materia}."}

    # REGRA 2: ENVIAR LINKS (Escrita/Validação)
    elif pedido.acao == "enviar_link":
        # Lógica Proposicional: Segurança Básica do Link
        if not (pedido.alvo.startswith("http://") or pedido.alvo.startswith("https://")):
            return {"status": "bloqueado", "motivo": "Link suspeito/inválido. Deve começar obrigatoriamente com http:// ou https://"}
        
        # Lógica de Primeira Ordem: Permissão de Escrita baseada no Papel
        vinculo = fatos_vinculos.get((pedido.usuario, pedido.disciplina))
        if vinculo in ["leciona", "monitor"]:
            return {"status": "permitido", "mensagem": f"Link seguro! Partilhado com a turma de {pedido.disciplina} com sucesso."}
        elif vinculo == "cursa":
            return {"status": "bloqueado", "motivo": f"Privilégios insuficientes. Alunos não podem partilhar links externos em {pedido.disciplina}."}
        else:
            return {"status": "bloqueado", "motivo": f"Intruso bloqueado. Sem vínculo com a turma de {pedido.disciplina}."}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)